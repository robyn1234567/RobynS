package za.ac.cput.userregistration.myswingapplication;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import org.apache.commons.validator.EmailValidator;

/**
 * Name:            Robyn
 * Surname:         Southgate
 * Student Number:  217243576
 * Assignment 2:    Swing Application
 */

public class CarMeetUp extends JFrame implements ActionListener {
    
    private JPanel panelNorth;
    private JPanel panelCenter, panelRB1, panelRB2;
    private JPanel panelSouth;
    
    private JLabel lblEventLogo;
    private JLabel lblHeading;
    
    private JLabel lblPadding1, lblPadding2, lblPadding3;
    private JLabel lblName;
    private JTextField txtName;
    private JLabel lblErrorName;
    
    private JLabel lblSurname;
    private JTextField txtSurname;
    private JLabel lblErrorSurname;
    
    private JLabel lblCellNumber;
    private JTextField txtCellNumber;
    private JLabel lblErrorCellNumber;
    
    private JLabel lblEmail;
    private JTextField txtEmail;
    private JLabel lblErrorEmail;
    
    private JLabel lblCarModel;
    private JTextField txtCarModel;
    private JLabel lblErrorCarModel;
    
    private JLabel lblRegistration;
    private JTextField txtRegistration;
    private JLabel lblErrorRegistration;
    
    private JLabel lblIdNumber;
    private JTextField txtIdNumber;
    private JLabel lblErrorIdNumber;
    
    private JLabel lblGender;
    private JPanel panelGender;
    private JRadioButton radMale;
    private JRadioButton radFemale;
    private JLabel lblPadding4, lblPadding5, lblPadding6;
    private JLabel lblErrorGender;
    private ButtonGroup genderButtonGroup;
    
    private JButton btnReset;
    private JButton btnSave;
    private JButton btnExit;
    private Font ft1, ft2, ft3;
    
    public CarMeetUp(){
        
        super("Car Meet Registration");
        
        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelRB1 = new JPanel();
        panelRB2 = new JPanel();
        panelSouth = new JPanel();
        
        lblEventLogo = new JLabel(new ImageIcon("McQueen.jpg"));
        lblHeading = new JLabel("Car Meet Registration");
        
        lblPadding1 = new JLabel();
        lblPadding2 = new JLabel();
        lblPadding3 = new JLabel();
        lblName = new JLabel("First Name: ");
        txtName = new JTextField(20);
        lblErrorName = new JLabel("*required");
        lblErrorName.setForeground(Color.red);
        lblErrorName.setVisible(false);
        
        lblSurname = new JLabel("Last Name: ");
        txtSurname = new JTextField(20);
        lblErrorSurname = new JLabel("*required");
        lblErrorSurname.setForeground(Color.red);
        lblErrorSurname.setVisible(false);
        
        lblCellNumber = new JLabel("Cell Number: ");
        txtCellNumber = new JTextField(10);
        lblErrorCellNumber = new JLabel("*required");
        lblErrorCellNumber.setForeground(Color.red);
        lblErrorCellNumber.setVisible(false);
        
        lblEmail = new JLabel("Email Address: ");
        txtEmail = new JTextField(20);
        lblErrorEmail = new JLabel("*please enter a valid email");
        lblErrorEmail.setForeground(Color.red);
        lblErrorEmail.setVisible(false);
        
        lblCarModel = new JLabel("Car Model: ");
        txtCarModel = new JTextField(15);
        lblErrorCarModel = new JLabel("*required");
        lblErrorCarModel.setForeground(Color.red);
        lblErrorCarModel.setVisible(false);
        
        lblRegistration = new JLabel("Registration: ");
        txtRegistration= new JTextField(10);
        lblErrorRegistration = new JLabel("*required");
        lblErrorRegistration.setForeground(Color.red);
        lblErrorRegistration.setVisible(false);
        
        lblIdNumber = new JLabel("ID number: ");
        txtIdNumber = new JTextField(13);
        lblErrorIdNumber = new JLabel("*required");
        lblErrorIdNumber.setForeground(Color.red);
        lblErrorIdNumber.setVisible(false);
        
        lblGender = new JLabel("Gender: ");
        panelGender = new JPanel();
        radFemale = new JRadioButton("Female");
        radMale = new JRadioButton("Male");
        genderButtonGroup = new ButtonGroup();
        genderButtonGroup.add(radFemale);
        genderButtonGroup.add(radMale);
        panelGender.setLayout(new GridLayout(1, 2));
        radFemale.setSelected(true);  
        panelGender.add(radFemale);
        panelGender.add(radMale);
        lblErrorGender = new JLabel("*required");
        lblErrorGender.setForeground(Color.red);
        lblErrorGender.setVisible(false);
        lblPadding4 = new JLabel();
        lblPadding5 = new JLabel();
        lblPadding6 = new JLabel();
        
        btnReset = new JButton("Reset");
        btnSave = new JButton("Save");
        btnExit = new JButton("Exit");
        
        ft1 = new Font("Arial", Font.BOLD, 32);
        ft2 = new Font("Arial", Font.PLAIN, 22);
        ft3 = new Font("Arial", Font.PLAIN, 24);
      }
    
     public void setGUI(){
        
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(10, 3));
        panelRB1.setLayout(new GridLayout(1, 2));
        panelRB2.setLayout(new GridLayout(1, 2));
        panelSouth.setLayout(new GridLayout(1, 2));
        
        panelNorth.add(lblEventLogo);
        panelNorth.add(lblHeading);
        lblHeading.setFont(ft1);
        lblHeading.setForeground(Color.red);
        panelNorth.setBackground(new Color(255, 255, 255));
        
        lblPadding1.setFont(ft1);
        panelCenter.add(lblPadding1);
        lblPadding2.setFont(ft1);
        panelCenter.add(lblPadding2);
        lblPadding3.setFont(ft1);
        panelCenter.add(lblPadding3);
        
        lblName.setFont(ft2);
        lblErrorName.setFont(ft2);
        lblErrorName.setForeground(Color.red);
        lblName.setHorizontalAlignment(JLabel.RIGHT);
        txtName.setFont(ft2);
        panelCenter.add(lblName);
        panelCenter.add(txtName);
        panelCenter.add(lblErrorName);
        
        lblSurname.setFont(ft2);
        lblErrorSurname.setFont(ft2);
        lblErrorSurname.setForeground(Color.red);
        lblSurname.setHorizontalAlignment(JLabel.RIGHT);
        txtSurname.setFont(ft2);
        panelCenter.add(lblSurname);
        panelCenter.add(txtSurname);
        panelCenter.add(lblErrorSurname);
        
        lblCellNumber.setFont(ft2);
        lblErrorCellNumber.setFont(ft2);
        lblErrorCellNumber.setForeground(Color.red);
        lblCellNumber.setHorizontalAlignment(JLabel.RIGHT);
        txtCellNumber.setFont(ft2);
        panelCenter.add(lblCellNumber);
        panelCenter.add(txtCellNumber);
        panelCenter.add(lblErrorCellNumber);
        
        lblEmail.setFont(ft2);
        lblErrorEmail.setFont(ft2);
        lblErrorEmail.setForeground(Color.red);
        lblEmail.setHorizontalAlignment(JLabel.RIGHT);
        txtEmail.setFont(ft2);
        panelCenter.add(lblEmail);
        panelCenter.add(txtEmail);
        panelCenter.add(lblErrorEmail);
        
        lblCarModel.setFont(ft2);
        lblErrorCarModel.setFont(ft2);
        lblErrorCarModel.setForeground(Color.red);
        lblCarModel.setHorizontalAlignment(JLabel.RIGHT);
        txtCarModel.setFont(ft2);
        panelCenter.add(lblCarModel);
        panelCenter.add(txtCarModel);
        panelCenter.add(lblErrorCarModel);
        
        lblRegistration.setFont(ft2);
        lblErrorRegistration.setFont(ft2);
        lblErrorRegistration.setForeground(Color.red);
        lblRegistration.setHorizontalAlignment(JLabel.RIGHT);
        txtRegistration.setFont(ft2);
        panelCenter.add(lblRegistration);
        panelCenter.add(txtRegistration);
        panelCenter.add(lblErrorRegistration);
        
        lblIdNumber.setFont(ft2);
        lblErrorIdNumber.setFont(ft2);
        lblErrorIdNumber.setForeground(Color.red);
        lblIdNumber.setHorizontalAlignment(JLabel.RIGHT);
        txtIdNumber.setFont(ft2);
        panelCenter.add(lblIdNumber);
        panelCenter.add(txtIdNumber);
        panelCenter.add(lblErrorIdNumber);
        
        lblGender.setFont(ft2);
        lblGender.setHorizontalAlignment(JLabel.RIGHT);
        radMale.setFont(ft2);
        radMale.setHorizontalAlignment(JRadioButton.CENTER);
        radFemale.setFont(ft2);
        radFemale.setHorizontalAlignment(JRadioButton.LEFT);
        radFemale.setSelected(true);
                
        genderButtonGroup.add(radMale);
        genderButtonGroup.add(radFemale);
        
        panelCenter.add(lblGender);      
        panelRB1.add(radMale);
        panelRB1.add(radFemale);
        panelCenter.add(panelRB1);
                
        btnReset.setFont(ft3);
        btnSave.setFont(ft3);
        btnExit.setFont(ft3);
        panelSouth.add(btnReset);
        panelSouth.add(btnSave);
        panelSouth.add(btnExit);
        
        panelRB1.setBackground(new Color(252, 105, 90));
        panelRB2.setBackground(new Color(252, 105, 90));
        panelCenter.setBackground(new Color(252, 105, 90));
        
        lblPadding4.setFont(ft1);
        panelCenter.add(lblPadding4);
        lblPadding5.setFont(ft1);
        panelCenter.add(lblPadding5);
        lblPadding6.setFont(ft1);
        panelCenter.add(lblPadding6);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        this.setSize(500, 500);
        this.pack();
        this.setVisible(true);
        
        }
     
     private boolean isInputValid() {
        boolean valid = true;
        if (txtName.getText().equals("")) {
            lblErrorName.setVisible(true);
            txtName.requestFocus();
            valid = false;
        }
        else 
            lblErrorName.setVisible(false);
        
        if (txtSurname.getText().equals("")) {
            lblErrorSurname.setVisible(true);
            txtSurname.requestFocus();
            valid = false;
        }
        else 
            lblCellNumber.setVisible(false);
        
        if (txtCellNumber.getText().equals("")) {
            lblErrorCellNumber.setVisible(true);
            txtCellNumber.requestFocus();
            valid = false;
        }
        else 
            lblErrorCellNumber.setVisible(false);
        
        if (txtEmail.getText().equals("")) {
            lblErrorEmail.setVisible(true);
            txtEmail.requestFocus();
            valid = false;
        }
        else 
            lblErrorEmail.setVisible(false);
        
        if (txtCarModel.getText().equals("")) {
            lblErrorCarModel.setVisible(true);
            txtCarModel.requestFocus();
            valid = false;
        }
        else 
            lblErrorCellNumber.setVisible(false);
        
        if (txtRegistration.getText().equals("")) {
            lblErrorRegistration.setVisible(true);
            txtRegistration.requestFocus();
            valid = false;
        }
        else 
            lblErrorRegistration.setVisible(false);
        
        if (txtIdNumber.getText().equals("")) {
            lblErrorIdNumber.setVisible(true);
            txtIdNumber.requestFocus();
            valid = false;
        }
        else 
            lblErrorIdNumber.setVisible(false);
        
        return valid;
    }
     
     public void resetForm(){
     
            txtName.setText("");
            lblErrorName.setVisible(false);
            txtSurname.setText("");
            lblErrorSurname.setVisible(false);
            txtCellNumber.setText("");
            lblErrorCellNumber.setVisible(false);
            txtEmail.setText("");
            lblErrorEmail.setVisible(false);
            txtCarModel.setText("");
            lblErrorCarModel.setVisible(false);
            txtRegistration.setText("");
            lblErrorRegistration.setVisible(false);
            txtIdNumber.setText("");
            lblErrorIdNumber.setVisible(false);
            radMale.setSelected(true);
        }
     
    @Override
     public void actionPerformed(java.awt.event.ActionEvent e) {
         
        if (e.getActionCommand().equals("Reset")) {
            
        } else if (e.getActionCommand().equals("Save")) {
            
        } if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
        }
     
     public static void main(String[] args) {
         
       new CarMeetUp().setGUI();
       
       // ArrayList<Integer> list = new ArrayList<>();
    } 
}
