package za.ac.cput.userregistration.myswingapplication;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 * Name:            Robyn
 * Surname:         Southgate
 * Student Number:  217243576
 * Assignment 2:    Swing Application
 * 
 */

public class CarRegistration {
    private String name;
    private String surname;
    private String cellNumber;
    private String email;
    private String carModel;
    private String registration;
    private String idNumber;
    private String gender;

public CarRegistration (String name, String surname, String cellNumber, String email, String carModel, String registration, String idNumber, String gender){
            this.name = name;
            this.surname = surname;
            this.cellNumber = cellNumber;
            this.email = email;
            this.carModel = carModel;
            this.registration = registration;
            this.idNumber = idNumber;
            this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getCellNumber() {
        return cellNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getCarModel() {
        return carModel;
    }

    public String getRegistration() {
        return registration;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public String getGender() {
        return gender;
    }

 public void save() {
        PrintWriter out = null;
        String message = "Thank you for your time, this information is saved.";
        
        try {
            out = new PrintWriter(new FileWriter("event.txt", true));
            out.println(name);
            out.println(surname);
            out.println(cellNumber);
            out.println(email);
            out.println(carModel);
            out.println(registration);
            out.println(idNumber);
            out.println(gender);
        }
        catch  (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
            finally {
            out.close();
        }
            JOptionPane.showMessageDialog(null, message, "Status", JOptionPane.INFORMATION_MESSAGE);
    }  
}